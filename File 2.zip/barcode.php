<!DOCTYPE html>
<html>
<head>

    <title>QR Code Generator SAE</title>
</head>
<body onload="window.print();">

    <style type="text/css">
        
        .hasil{
            text-align: center;
        }
		
		
    </style>
    <div class="hasil">
        <?php 


            // isi qrcode yang ingin dibuat. akan muncul saat di scan
            $isi = $_GET['isi_konten'];

            // memanggil library php qrcode
            include "phpqrcode/qrlib.php"; 

            // nama folder tempat penyimpanan file qrcode
            $penyimpanan = "temp/";

            // membuat folder dengan nama "temp"
            if (!file_exists($penyimpanan))
             mkdir($penyimpanan);

            // perintah untuk membuat qrcode dan menyimpannya dalam folder temp
            // atur level pemulihan datanya dengan QR_ECLEVEL_L | QR_ECLEVEL_M | QR_ECLEVEL_Q | QR_ECLEVEL_H
            // atur pixel qrcode pada parameter ke 4
            // atur jarak frame pada parameter ke 5
            QRcode::png($isi, $penyimpanan.'hasil_qrcode.png', QR_ECLEVEL_L, 6, 2); 
         
            // menampilkan qrcode
			for($x=1; $x<=6; $x++){
				echo '<img src="'.$penyimpanan.'hasil_qrcode.png">';
			}
  /*          echo '<img src="'.$penyimpanan.'hasil_qrcode.png">';
			echo'</br>';
			echo '<a href="'.$penyimpanan.'hasil_qrcode.png"></a>';
			echo '<button onClick="window.print();">Cetak</button>';
			*/
			
			
			
			 

        

        ?>
    </div>
	</body>
</html>