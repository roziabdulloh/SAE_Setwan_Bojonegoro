-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 05 Des 2022 pada 14.55
-- Versi server: 10.4.6-MariaDB
-- Versi PHP: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_arsip`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_disposisi`
--

CREATE TABLE `tbl_disposisi` (
  `id_disposisi` int(10) NOT NULL,
  `tujuan` varchar(250) NOT NULL,
  `isi_disposisi` mediumtext NOT NULL,
  `sifat` varchar(100) NOT NULL,
  `catatan` varchar(250) NOT NULL,
  `id_surat` int(10) NOT NULL,
  `id_user` tinyint(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_instansi`
--

CREATE TABLE `tbl_instansi` (
  `id_instansi` tinyint(1) NOT NULL,
  `institusi` varchar(150) NOT NULL,
  `nama` varchar(150) NOT NULL,
  `alamat` varchar(150) NOT NULL,
  `kabid` varchar(50) NOT NULL,
  `nip` varchar(25) NOT NULL,
  `website` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `logo` varchar(250) NOT NULL,
  `id_user` tinyint(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_instansi`
--

INSERT INTO `tbl_instansi` (`id_instansi`, `institusi`, `nama`, `alamat`, `kabid`, `nip`, `website`, `email`, `logo`, `id_user`) VALUES
(1, 'PIMPINAN CABANG', 'IKATAN PELAJAR NAHDLATUL ULAMA BOJONEGORO', 'Jl. Ahmad Yani No. 12, Sukorejo, Bojonegoro', 'JAMALUDIN AHMAD HUSAIN', '123 456 789 123', 'https://ipnuippnubojonegoro.or.id/', 'admin@ipnuippnubojonegoro.or.id', 'ipnu png.png', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_klasifikasi`
--

CREATE TABLE `tbl_klasifikasi` (
  `id_klasifikasi` int(5) NOT NULL,
  `kode` varchar(30) NOT NULL,
  `nama` varchar(250) NOT NULL,
  `uraian` mediumtext NOT NULL,
  `id_user` tinyint(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_klasifikasi`
--

INSERT INTO `tbl_klasifikasi` (`id_klasifikasi`, `kode`, `nama`, `uraian`, `id_user`) VALUES
(3, 'A', 'Surat Pemberitahuan', 'Pemberitahuan', 1),
(4, 'B', 'Surat Undangan', 'Undangan', 1),
(5, 'C', 'Surat Permohonan', 'Permohonan', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_sett`
--

CREATE TABLE `tbl_sett` (
  `id_sett` tinyint(1) NOT NULL,
  `surat_masuk` tinyint(2) NOT NULL,
  `surat_keluar` tinyint(2) NOT NULL,
  `referensi` tinyint(2) NOT NULL,
  `id_user` tinyint(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_sett`
--

INSERT INTO `tbl_sett` (`id_sett`, `surat_masuk`, `surat_keluar`, `referensi`, `id_user`) VALUES
(1, 50, 10, 10, 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_surat_keluar`
--

CREATE TABLE `tbl_surat_keluar` (
  `id_surat` int(10) NOT NULL,
  `no_agenda` int(10) NOT NULL,
  `tujuan` varchar(250) NOT NULL,
  `no_surat` varchar(50) NOT NULL,
  `isi` mediumtext NOT NULL,
  `kode` varchar(30) NOT NULL,
  `tgl_surat` date NOT NULL,
  `tgl_catat` date NOT NULL,
  `file` varchar(250) NOT NULL,
  `keterangan` varchar(250) NOT NULL,
  `id_user` tinyint(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_surat_keluar`
--

INSERT INTO `tbl_surat_keluar` (`id_surat`, `no_agenda`, `tujuan`, `no_surat`, `isi`, `kode`, `tgl_surat`, `tgl_catat`, `file`, `keterangan`, `id_user`) VALUES
(3, 1, 'PP IPNU', '001', 'Untuk Lampiran Permohonan Surat Pengesahan', 'C', '2021-01-06', '2022-08-19', '9064-001 REKOM PCNU.docx', 'Permohonan Surat pengesahan', 1),
(4, 2, 'PP IPNU', '002', 'Permohonan Surat Pengesahan', 'c', '2020-12-22', '2022-08-19', '7498-002 permohonan SP PP.docx', 'Pengajuan Surat Pengesahan', 1),
(5, 3, 'PW IPNU Jawa Timur', '003', 'Permohonan Surat Rekomendasi ', 'C', '2021-01-21', '2022-08-19', '1833-003 permohonan REKOM PW.docx', 'Permohonan Surat Rekomendasi', 1),
(6, 4, 'Pengurus PC IPNU', '004', 'Surat Tugas Kegiatan', 'z', '2021-12-16', '2022-08-19', '7770-004 Surat Tugas 2020.docx', 'Surat Tugas Kegiatan', 1),
(7, 5, 'Pengurus PC IPNU', '005', 'Surat Tugas Pimpinan Sidang Konferensi PAC IPNU Kepohbaru', 'z', '2021-12-19', '2022-08-19', '1786-005 Surat Tugas Konferancab Kepohbaru.docx', 'Surat Tugas Dept Organisasi', 1),
(8, 6, 'Pengurus PC IPNU', '006', 'Surat Tugas Pimpinan Sidang Konferancab PC IPNU Gayam', 'z', '2020-12-27', '2022-08-19', '7263-006 Surat Tugas Konferancab Gayam.docx', 'Surat Tugas Dept Organisasi', 1),
(9, 7, 'Pengurus PC IPNU', '007', 'Surat Tugas KLB PAC IPNU Malo', 'z', '2021-01-10', '2022-08-19', '410-007 Surat Tugas KLB Malo.docx', 'Surat Tugas Dept Organisasi', 1),
(10, 8, 'PW IPNU Jawa Timur', '008', 'Permohonan Melantik PC IPNU Bojonegoro', 'z', '2021-01-21', '2022-08-19', '4861-08 - 011 Surat Permohonan ke PW IPNU Jatim.docx', 'Surat Permohonan Melantik', 1),
(11, 9, 'PW IPNU Jawa Timur', '009', 'Undangan Pelantikan PW IPNU Jawa Timur', 'z', '2021-01-21', '2022-08-19', '126-08 - 011 Surat Permohonan ke PW IPNU Jatim.docx', 'Surat Undangan', 1),
(12, 10, 'PW IPNU Jawa Timur', '010', 'Surat Pemberitahuan Pelantikan', 'z', '2022-01-21', '2022-08-19', '6356-08 - 011 Surat Permohonan ke PW IPNU Jatim.docx', 'Pemberitahuan Pelantikan PC IPNU Bojonegoro', 1),
(13, 11, 'Pengurus PC IPNU Bojonegoro', '011', 'Undangan Pelantikan Pengurus PC IPNU Bojonegoro', 'z', '2021-01-22', '2022-08-19', '92-08 - 011 Surat Permohonan ke PW IPNU Jatim.docx', 'Undnagan Pelantikan ', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_surat_masuk`
--

CREATE TABLE `tbl_surat_masuk` (
  `id_surat` int(10) NOT NULL,
  `no_agenda` int(10) NOT NULL,
  `no_surat` varchar(50) NOT NULL,
  `asal_surat` varchar(250) NOT NULL,
  `isi` mediumtext NOT NULL,
  `kode` varchar(30) NOT NULL,
  `indeks` varchar(30) NOT NULL,
  `tgl_surat` date NOT NULL,
  `tgl_diterima` date NOT NULL,
  `file` varchar(250) NOT NULL,
  `keterangan` varchar(250) NOT NULL,
  `id_user` tinyint(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_surat_masuk`
--

INSERT INTO `tbl_surat_masuk` (`id_surat`, `no_agenda`, `no_surat`, `asal_surat`, `isi`, `kode`, `indeks`, `tgl_surat`, `tgl_diterima`, `file`, `keterangan`, `id_user`) VALUES
(7, 1, '014', 'PKPT IPNU SUNAN GIRI', 'MAKESTA (Masa Kesetiaan Anggota)', 'A', 'Pemberitahuan', '2022-08-11', '2022-08-11', '6681-SURAT PEMBERITAHUAN pkpt.pdf', 'Tanpa Disposisi', 1),
(8, 2, '012', 'PKPT IPNU UNUGIRI', 'Permohonanan Pembaiatan', 'C', 'Permohonan', '2022-07-12', '2022-08-11', '5155-Permohonana baiat - PKPT IPNU IPPNU UNUGIRI.pdf', 'Tanpa Disposisi', 1),
(9, 3, '013', 'PKPT IPNU UNUGIRI', 'Permohonan Peminjaman Barang', 'C', 'Permohonan', '2022-06-12', '2022-08-11', '318-Perminjaman Barang PC - PKPT IPNU IPPNU UNUGIRI.pdf', 'Tanpa Disposisi', 1),
(10, 4, '36', 'PAC IPNU IPPNU BALEN', 'Undangan Pembukaan', 'B', 'Undangan', '2022-07-05', '2022-08-11', '8702-Undangan PC IPNU IPNU Bojonegoro - Mrouf Nasrullah.pdf', 'Tanpa Disposisi', 1),
(11, 5, '07', 'PKPT IPNU IPPNU STAI ATTANWIR', 'MAKESTA (Masa Kesetiaan Anggota)', 'B', 'Undangan', '2022-06-26', '2022-08-11', '9329-UNDANGAN PC IPNU - Luluk Mas Ula.pdf', 'Tanpa Disposisi', 1),
(12, 6, '002', 'PKPT IPNU IPPNU STAI ATTANWIR', 'MAKESTA (Masa Kesetiaan Anggota)', 'A', 'Pemberitahuan', '2022-06-29', '2022-08-11', '3887-Pemb. PC IPNU IPPNU Bojongeoro - Luluk Mas Ula.pdf', 'Tanpa Disposisi', 1),
(13, 7, '031', 'PKPT IPNU IPPNU STAI ATTANWIR', 'Permohonan Pemateri', 'C', 'Permohonan', '2022-06-29', '2022-08-11', '6656-Kesediaan PC IPNU IPPNU - Luluk Mas Ula.pdf', 'Disposisi', 1),
(14, 8, '02', 'PR IPNU IPPNU SUMBERJO', 'MAKESTA (Masa Kesetiaan Anggota)', 'A', 'Pemberitahuan', '2022-08-30', '2022-08-11', '3803-SURAT PEMBERITAHUAN CABANG IPNU MAKESTA 2021 - Soleh Wibowo.pdf', 'Tanpa Disposisi', 1),
(15, 9, '009', 'Pac ipnu ippnu kec.sugihwaras', 'MAKESTA (Masa Kesetiaan Anggota)', 'B', 'Undangan', '2022-06-30', '2022-08-11', '794-PC. Makesta Kordes Selatan - Abduh Fery.pdf', 'Tanpa Disposisi', 1),
(16, 10, '022', 'PAC IPNU IPPNU KASIMAN', 'MAKESTA (Masa Kesetiaan Anggota)', 'B', 'Undangan', '2022-07-12', '2022-08-11', '8171-UNDANGAN MAKESTA PAC KASIMAN - reza hadi.pdf', 'Tanpa Disposisi', 1),
(17, 11, '004', 'PAC IPNU IPPNU KASIMAN', 'MAKESTA (Masa Kesetiaan Anggota)', 'A', 'Pemberitahuan', '2022-08-12', '2022-08-11', '7897-PEMBERITAHUAN MAKESTA PAC KASIMAN - reza hadi.pdf', 'Tanpa Disposisi', 1),
(18, 12, '028', 'PAC IPNU IPPNU PADANGAN', 'KONFERANCAB', 'B', 'Undangan', '2022-07-10', '2022-08-11', '665-IMG-20211109-WA0069 - Indro Setyo Bakhrudin.jpg', 'Tanpa Disposisi', 1),
(19, 13, '027', 'PAC IPNU IPPNU PADANGAN', 'KONFERANCAB', 'C', 'Permohonan Pimpinan Sidang', '2022-06-13', '2022-08-11', '1664-IMG-20211109-WA0082 - Indro Setyo Bakhrudin.jpg', 'Disposisi Departemen Organisasi', 1),
(20, 14, '081', 'PAC IPNU KAPAS', 'MAKESTA (Masa Kesetiaan Anggota)', 'B', 'Undangan', '2022-07-10', '2022-08-11', '9858-IMG20211119112601 - rifqi project.jpg', 'Tanpa Disposisi', 1),
(21, 15, '076', 'PAC IPNU KAPAS', 'Permohonan Pemateri', 'C', 'Permohonan', '2022-06-13', '2022-08-11', '6845-IMG20211119112509 - rifqi project.jpg', 'Disposisi Departemen Kaderisasi', 1),
(22, 16, '01', 'PAC IPNU IPPNU Ngasem', 'MAKESTA (Masa Kesetiaan Anggota)', 'A', 'Pemberitahuan', '2022-06-06', '2022-08-11', '866-02 SURAT PEMBERITAHUAN PC IPNU-IPPNU BOJONEGORO - Agil Mutiara Nurjanah.pdf', 'Tanpa Disposisi', 1),
(23, 17, '04', 'PAC IPNU IPPNU Ngasem', 'Permohonan Pemateri', 'C', 'Permohonan', '2022-05-17', '2022-08-11', '7391-04 PERMOHONAN PEMATERI ADMINISTRASI - Agil Mutiara Nurjanah.pdf', 'Disposisi Departemen Kaderisasi', 1),
(24, 18, '13', 'PIMPINAN ANAK CABANG IPNU IPPNU SUMBERREJO', 'Permohonan Fasilitator', 'C', 'Permohonan', '2022-06-05', '2022-08-11', '861-IMG-20211218-WA0008 - Ainur Roziqin.jpg', 'Disposisi Departemen Kaderisasi', 1),
(25, 19, '006', 'PIMPINAN ANAK CABANG IPNU IPPNU SUMBERREJO', 'LAKMUD', 'A', 'Pemberitahuan', '2022-06-05', '2022-08-11', '9616-002-SURAT PEMBERITAHUAN LAKMUD PC IPNU - Muhammad Abdul Aziz.pdf', 'Tanpa Disposisi', 1),
(26, 20, '001', 'PAC IPNU GAYAM', 'LAKMUD', 'A', 'Pemberitahuan', '2022-05-30', '2022-08-12', '2046-Pemberitahuan PC IPNU IPPNU - PAC IPNU IPPNU GAYAM.pdf', 'Tanpa Disposisi', 1),
(27, 21, '007', 'PAC IPNU GAYAM', 'Permohonan Pemateri', 'C', 'Permohonan', '2022-05-30', '2022-08-12', '7634-Permohonan Instruktur - PAC IPNU IPPNU GAYAM.pdf', 'Disposisi Departemen Kaderisasi', 1),
(28, 22, '015', 'PAC IPNU IPPNU GAYAM', 'Permohonan Pengukuhan', 'C', 'Permohonan', '2022-06-14', '2022-08-12', '4296-PERMOHONAN PENGUKUHAN - PAC IPNU IPPNU GAYAM.pdf', 'Tindak Lanjut Ketua', 1),
(29, 23, '008', 'PAC IPNU PADANGAN', 'Seminar dan Pelantikan', 'B', 'Undangan', '2022-05-10', '2022-08-12', '4613-Undangan pelantikan pac padangan - Indro Setyo Bakhrudin.pdf', 'Tindak Lanjut Ketua', 1),
(30, 24, '035', 'PKPT IPNU IPPNU UNUGIRI ', 'LAKMUD', 'A', 'Pemberitahuan', '2022-05-03', '2022-08-12', '1417-UD PC PEMBERITAHUAN -1 - pkptunugiri bjn.pdf', 'Tanpa Disposisi', 1),
(31, 25, '036', 'PKPT IPNU IPPNU UNUGIRI ', 'Permohonan Pengukuhan', 'C', 'Permohonan', '2022-05-22', '2022-08-12', '4960-UD PC PERMOHONAAN PENGUKUHAN - pkptunugiri bjn.pdf', 'Tindak Lanjut Ketua', 1),
(32, 26, '016', 'Sri Yanto', 'Pelantikan Pengurus PAC IPNU IPPNU\r\nKecamatan Ngambon Masa Khitmad 2022-2024,', 'B', 'Undangan', '2022-04-03', '2022-08-12', '7048-Undangan PC2 - IPNU IPPNU.pdf', 'Tindak Lanjut Ketua', 1),
(33, 27, '017', 'PAC IPNU IPPNU GAYAM', 'MAKESTA (Masa Kesetiaan Anggota)', 'A', 'Pemberitahuan', '2022-04-17', '2022-08-12', '9041-Pemberitahuan Makesta PC IPNU - PAC IPNU IPPNU GAYAM.pdf', 'Tanpa Disposisi', 1),
(34, 28, '023', 'PAC IPNU Kec. Kapas', 'LAKMUD (Latihan Kader Muda)', 'B', 'Undangan', '2022-04-09', '2022-08-12', '8172-UndanganPC IPNU IPPNU 20 - PAC IPNU IPPNU KAPAS.pdf', 'Tanpa Disposisi', 1),
(35, 29, '113', 'PAC IPNU Kec. Kapas', 'Permohonan Instruktur', 'C', 'Permohonan', '2022-04-09', '2022-08-12', '754-Permohonan Instruktur LAMKUD - PAC IPNU IPPNU KAPAS.pdf', 'Disposisi Departemen Kaderisasi', 1),
(36, 30, '109', 'PAC IPNU Kec. Kapas', 'LAKMUD (Latihan Kader Muda)', 'A', 'Pemberitahuan', '2022-04-09', '2022-08-12', '8759-Pemberitahuan PC IPNU IPPNU fix - PAC IPNU IPPNU KAPAS.pdf', 'Tanpa Disposisi', 1),
(40, 31, '026', 'PAC DANDER', 'Permohonan Penerbitan Sertifikat', 'C', 'Penting', '2022-03-19', '2022-09-06', '6887-SURAT PERMOHONAN PENERBITAN SERTIFIKAT LAKMUD DANDER - AFK Coffee.docx', 'Sertifikat Tanpa Disposisi', 1),
(41, 32, '029', 'PAC DANDER', 'Permohonan Penerbitan Sertifikat', 'C', 'Penting', '2022-03-19', '2022-09-06', '4523-SURAT PERMOHONAN PENERBITAN SERTIFIKAT DIKLATAMA DANDER - AFK Coffee.docx', 'Sertifikat Tanpa Disposisi', 1),
(42, 33, '030', 'PAC IPNU-IPPNU Ngasem', 'Surat Pemberitahuan LAKMUD', 'A', 'Biasa', '2022-07-14', '2022-09-06', '673-PEMBERITAHUAN PC IPNU - Agil Mutiara Nurjanah.pdf', 'Pemberitahuan LAKMUD Tanpa Disposisi', 1),
(43, 34, '032', 'PAC IPNU-IPPNU Ngasem', 'Undangan LAKMUD', 'B', 'Biasa', '2022-07-14', '2022-09-06', '6268-UNDANGAN PC IPNU - Agil Mutiara Nurjanah.pdf', 'Tanpa Disposisi', 1),
(44, 35, '033', 'PAC IPNU-IPPNU Ngasem', 'Permohonan Screaning LAKMUD', 'C', 'Penting', '2022-07-11', '2022-09-06', '3773-PERMOHONAN SCREANING - Agil Mutiara Nurjanah.pdf', 'Disposisi', 1),
(45, 36, '034', 'PAC IPNU-IPPNU Ngasem', 'Permohonan Fasilitator LAKMUD', 'C', 'Penting', '2022-07-14', '2022-09-06', '8411-PERMOHONAN FASILITATOR - Agil Mutiara Nurjanah.pdf', 'Disposisi', 1),
(46, 37, '037', 'PAC IPNU-IPPNU Ngasem', 'Permohonan Pemateri LAKMUD', 'C', 'Penting', '2022-07-16', '2022-09-06', '4863-PERMOHONAN PEMATERI - Agil Mutiara Nurjanah.pdf', 'Disposisi', 1),
(47, 38, '038', 'PAC IPNU-IPPNU Ngasem', 'Permohonan Pengukuhan LAKMUD', 'C', 'Penting', '2022-07-17', '2022-09-06', '1324-PERMOHONAN PENGUKUHAN - Agil Mutiara Nurjanah.pdf', 'Disposisi', 1),
(48, 39, '039', 'PAC IPNU-IPPNU Ngasem', 'Permohonan Pemateri LAKMUD', 'C', 'Penting', '2022-07-14', '2022-09-06', '4089-PERMOHONAN PEMATERI PC (2) - Agil Mutiara Nurjanah.pdf', 'Disposisi', 1),
(49, 40, '040', 'PAC IPNU-IPPNU Baureno', 'Pemberitahuan Pelantikan dan RAKER ', 'A', 'Biasa', '2022-07-17', '2022-09-06', '9133-pemberitahuan pc - Naufal Inzaghi.docx', 'Pemberitahuan Tanpa Disposisi', 1),
(50, 41, '041', 'PAC IPNU-IPPNU Baureno', 'Permohonan Melantik', 'C', 'Penting', '2022-07-17', '2022-09-07', '6608-PERMOHONAN MELANTIK - Naufal Inzaghi.docx', 'Disposisi', 1),
(51, 42, '042', 'PAC IPNU-IPPNU Sumberrejo', 'Pemberitahuan Peringatan Hari Besar Islam (PHB)', 'A', 'Biasa', '2022-08-19', '2022-09-07', '9867-005- pemberitahuan PC IPNU BJN - Pelajar NU Sumberrejo.pdf', 'Tanpa Disposisi', 1),
(52, 43, '043', 'PAC IPNU IPPNU PADANGAN', 'Undangan MAKESTA (Masa Kesetiaan Anggota)', 'B', 'Biasa', '2022-08-26', '2022-09-07', '1301-UNDANGAN_PC - KB-TK Muslimat Nurul Ummah Purwosari.pdf', 'Tanpa Disposisi', 1),
(53, 44, '044', 'PAC IPNU IPPNU PADANGAN', 'Permohonan Pemateri MAKESTA', 'C', 'Penting', '2022-08-27', '2022-09-07', '521-(KE-IPNU-AN)_Permohonan_Pemateri_Makesta_[1][1] - KB-TK Muslimat Nurul Ummah Purwosari.pdf', 'Disposisi', 1),
(54, 45, '045', 'PAC IPNU IPPNU PADANGAN', 'Permohonan Pemateri MAKESTA', 'C', 'Penting', '2022-08-27', '2022-09-07', '3386-administrasi_permohonan pemateri - KB-TK Muslimat Nurul Ummah Purwosari.pdf', 'Disposisi', 1),
(55, 46, '046', 'PAC IPNU IPPNU PADANGAN', 'Permohonan Pembaiatan', 'C', 'Penting', '2022-08-28', '2022-09-07', '8303-Pembaiatan_Surat_Permohonan_ - KB-TK Muslimat Nurul Ummah Purwosari.pdf', 'Disposisi', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id_user` tinyint(2) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(35) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `nip` varchar(25) NOT NULL,
  `admin` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_user`
--

INSERT INTO `tbl_user` (`id_user`, `username`, `password`, `nama`, `nip`, `admin`) VALUES
(1, 'daniyusuf', 'b8d5be7da9b82ebc7c4c2d50184ac07b', 'Dani Yusuf', '-', 1),
(2, 'dinanda', 'cb2d5d94a25f14f5d04e058bd12c38ce', 'dinanda', '-', 2);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tbl_disposisi`
--
ALTER TABLE `tbl_disposisi`
  ADD PRIMARY KEY (`id_disposisi`),
  ADD KEY `id_user` (`id_user`),
  ADD KEY `id_surat` (`id_surat`);

--
-- Indeks untuk tabel `tbl_instansi`
--
ALTER TABLE `tbl_instansi`
  ADD PRIMARY KEY (`id_instansi`),
  ADD KEY `id_user` (`id_user`);

--
-- Indeks untuk tabel `tbl_klasifikasi`
--
ALTER TABLE `tbl_klasifikasi`
  ADD PRIMARY KEY (`id_klasifikasi`),
  ADD KEY `id_user` (`id_user`);

--
-- Indeks untuk tabel `tbl_sett`
--
ALTER TABLE `tbl_sett`
  ADD PRIMARY KEY (`id_sett`),
  ADD KEY `id_user` (`id_user`);

--
-- Indeks untuk tabel `tbl_surat_keluar`
--
ALTER TABLE `tbl_surat_keluar`
  ADD PRIMARY KEY (`id_surat`),
  ADD KEY `id_user` (`id_user`);

--
-- Indeks untuk tabel `tbl_surat_masuk`
--
ALTER TABLE `tbl_surat_masuk`
  ADD PRIMARY KEY (`id_surat`),
  ADD KEY `id_user` (`id_user`);

--
-- Indeks untuk tabel `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tbl_disposisi`
--
ALTER TABLE `tbl_disposisi`
  MODIFY `id_disposisi` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `tbl_klasifikasi`
--
ALTER TABLE `tbl_klasifikasi`
  MODIFY `id_klasifikasi` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `tbl_surat_keluar`
--
ALTER TABLE `tbl_surat_keluar`
  MODIFY `id_surat` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT untuk tabel `tbl_surat_masuk`
--
ALTER TABLE `tbl_surat_masuk`
  MODIFY `id_surat` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT untuk tabel `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id_user` tinyint(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `tbl_disposisi`
--
ALTER TABLE `tbl_disposisi`
  ADD CONSTRAINT `tbl_disposisi_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `tbl_user` (`id_user`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `tbl_disposisi_ibfk_2` FOREIGN KEY (`id_surat`) REFERENCES `tbl_surat_masuk` (`id_surat`);

--
-- Ketidakleluasaan untuk tabel `tbl_instansi`
--
ALTER TABLE `tbl_instansi`
  ADD CONSTRAINT `tbl_instansi_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `tbl_user` (`id_user`);

--
-- Ketidakleluasaan untuk tabel `tbl_klasifikasi`
--
ALTER TABLE `tbl_klasifikasi`
  ADD CONSTRAINT `tbl_klasifikasi_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `tbl_user` (`id_user`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `tbl_sett`
--
ALTER TABLE `tbl_sett`
  ADD CONSTRAINT `tbl_sett_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `tbl_user` (`id_user`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `tbl_surat_keluar`
--
ALTER TABLE `tbl_surat_keluar`
  ADD CONSTRAINT `tbl_surat_keluar_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `tbl_user` (`id_user`);

--
-- Ketidakleluasaan untuk tabel `tbl_surat_masuk`
--
ALTER TABLE `tbl_surat_masuk`
  ADD CONSTRAINT `tbl_surat_masuk_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `tbl_user` (`id_user`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
