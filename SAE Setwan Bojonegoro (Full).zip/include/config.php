<?php
$host     = "localhost";    // Nama host
$username = "root";         // Username database
$password = "";   // Password database
$database = "db_sae";   // Nama database
