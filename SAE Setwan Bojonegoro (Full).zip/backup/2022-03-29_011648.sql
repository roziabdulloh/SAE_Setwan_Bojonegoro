DROP TABLE tbl_disposisi;

CREATE TABLE `tbl_disposisi` (
  `id_disposisi` int(10) NOT NULL AUTO_INCREMENT,
  `tujuan` varchar(250) NOT NULL,
  `isi_disposisi` mediumtext NOT NULL,
  `sifat` varchar(100) NOT NULL,
  `catatan` varchar(250) NOT NULL,
  `id_surat` int(10) NOT NULL,
  `id_user` tinyint(2) NOT NULL,
  PRIMARY KEY (`id_disposisi`),
  KEY `id_user` (`id_user`),
  KEY `id_surat` (`id_surat`),
  CONSTRAINT `tbl_disposisi_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `tbl_user` (`id_user`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `tbl_disposisi_ibfk_2` FOREIGN KEY (`id_surat`) REFERENCES `tbl_surat_masuk` (`id_surat`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO tbl_disposisi VALUES("1","Departemen Organisasi","Untuk mengambil alih sementara tugas dan wewenang Ketua dalam memimpin organisasi.","Penting","Surat Mandat ini berlaku mulai tanggal  30 September 2010  s.d  01 Oktober  2010. ","1","1");
INSERT INTO tbl_disposisi VALUES("5","Departemen Organisasi","Ketua","Penting","Ketua","2","1");



DROP TABLE tbl_instansi;

CREATE TABLE `tbl_instansi` (
  `id_instansi` tinyint(1) NOT NULL,
  `institusi` varchar(150) NOT NULL,
  `nama` varchar(150) NOT NULL,
  `alamat` varchar(150) NOT NULL,
  `kabid` varchar(50) NOT NULL,
  `nip` varchar(25) NOT NULL,
  `website` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `logo` varchar(250) NOT NULL,
  `id_user` tinyint(2) NOT NULL,
  PRIMARY KEY (`id_instansi`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `tbl_instansi_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `tbl_user` (`id_user`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO tbl_instansi VALUES("1","PIMPINAN CABANG","IKATAN PELAJAR NAHDLATUL ULAMA BOJONEGORO","Jl. Ahmad Yani No. 12, Sukorejo, Bojonegoro","JAMALUDIN AHMAD HUSAIN","-","https://ipnuippnubojonegoro.or.id/","admin@ipnuippnubojonegoro.or.id","ipnu png.png","1");



DROP TABLE tbl_klasifikasi;

CREATE TABLE `tbl_klasifikasi` (
  `id_klasifikasi` int(5) NOT NULL AUTO_INCREMENT,
  `kode` varchar(30) NOT NULL,
  `nama` varchar(250) NOT NULL,
  `uraian` mediumtext NOT NULL,
  `id_user` tinyint(2) NOT NULL,
  PRIMARY KEY (`id_klasifikasi`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `tbl_klasifikasi_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `tbl_user` (`id_user`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO tbl_klasifikasi VALUES("1","A","Surat Permohonan","Surat Pemintaan Dinas","1");



DROP TABLE tbl_sett;

CREATE TABLE `tbl_sett` (
  `id_sett` tinyint(1) NOT NULL,
  `surat_masuk` tinyint(2) NOT NULL,
  `surat_keluar` tinyint(2) NOT NULL,
  `referensi` tinyint(2) NOT NULL,
  `id_user` tinyint(2) NOT NULL,
  PRIMARY KEY (`id_sett`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `tbl_sett_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `tbl_user` (`id_user`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO tbl_sett VALUES("1","10","10","10","2");



DROP TABLE tbl_surat_keluar;

CREATE TABLE `tbl_surat_keluar` (
  `id_surat` int(10) NOT NULL AUTO_INCREMENT,
  `no_agenda` int(10) NOT NULL,
  `tujuan` varchar(250) NOT NULL,
  `no_surat` varchar(50) NOT NULL,
  `isi` mediumtext NOT NULL,
  `kode` varchar(30) NOT NULL,
  `tgl_surat` date NOT NULL,
  `tgl_catat` date NOT NULL,
  `file` varchar(250) NOT NULL,
  `keterangan` varchar(250) NOT NULL,
  `id_user` tinyint(2) NOT NULL,
  PRIMARY KEY (`id_surat`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `tbl_surat_keluar_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `tbl_user` (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO tbl_surat_keluar VALUES("1","1","DPU","233.111/PIP/444.11","permohonan","A","2022-01-31","2022-02-01","653-Logo_Kabupaten_Bojonegoro.png","permohonan","1");



DROP TABLE tbl_surat_masuk;

CREATE TABLE `tbl_surat_masuk` (
  `id_surat` int(10) NOT NULL AUTO_INCREMENT,
  `no_agenda` int(10) NOT NULL,
  `no_surat` varchar(50) NOT NULL,
  `asal_surat` varchar(250) NOT NULL,
  `isi` mediumtext NOT NULL,
  `kode` varchar(30) NOT NULL,
  `indeks` varchar(30) NOT NULL,
  `tgl_surat` date NOT NULL,
  `tgl_diterima` date NOT NULL,
  `file` varchar(250) NOT NULL,
  `keterangan` varchar(250) NOT NULL,
  `id_user` tinyint(2) NOT NULL,
  PRIMARY KEY (`id_surat`),
  KEY `id_user` (`id_user`),
  CONSTRAINT `tbl_surat_masuk_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `tbl_user` (`id_user`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO tbl_surat_masuk VALUES("1","1","122.133/sp/122.11","bapeda","permohonan","A","permohonan liputan","2022-02-01","2022-02-01","3545-Logo_Kabupaten_Bojonegoro.png","permohonan","1");
INSERT INTO tbl_surat_masuk VALUES("2","2","002","PAC IPNU KANOR","Pengesahkan pengurus PAC IPNU Kanor masa khidmad 2021-2023","A","PERMOHONAN MELANTIK","2022-03-28","2022-03-28","8457-002 Surat Permohonan Melantik.doc","Pelantikan ","1");
INSERT INTO tbl_surat_masuk VALUES("3","3","003s","PAC IPNU KANOR","asas","A","PERMOHONAN MELANTIK","2022-03-28","2022-03-28","4259-001 Surat Permohonan Izin Tempat.doc","Pelantikan ","1");
INSERT INTO tbl_surat_masuk VALUES("4","4","003srq","PAC IPNU KANOR","aadwd","A","PERMOHONAN MELANTIK","2022-03-28","2022-03-29","8204-003 Surat Undangan Camat Bojonegoro.doc","sss","1");
INSERT INTO tbl_surat_masuk VALUES("5","5","asadxzczs","PAC IPNU KANOR","asaczxczcwszd","b","PERMOHONAN MELANTIK","2022-03-29","2022-03-29","7848-003 Surat Undangan Fix.doc","Pelantikan ","1");



DROP TABLE tbl_user;

CREATE TABLE `tbl_user` (
  `id_user` tinyint(2) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `password` varchar(35) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `nip` varchar(25) NOT NULL,
  `admin` tinyint(1) NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO tbl_user VALUES("1","daniyusuf","b8d5be7da9b82ebc7c4c2d50184ac07b","Dani Yusuf","-","1");
INSERT INTO tbl_user VALUES("2","dinanda","cb2d5d94a25f14f5d04e058bd12c38ce","dinanda","-","2");
INSERT INTO tbl_user VALUES("3","biasa","428d0e7a73d305245da72e307ae51e57","biasa","-","3");



