<?php 
    require 'naivebayes.php';

    $data = olahData(getData("dt_training.txt"));    
    
    function getData($file){
        $fh = fopen($file, "r");
        $i = 0;
    
        while (!feof($fh)) {
            $line[$i] = fgets($fh);
            $i++;
        }
               
        fclose($fh);
        return $line;
    }
    
    function olahData($data){
        $i = 0;
        $olah = null;
        foreach ($data as $d) {
            $olah[$i] = array_map("trim", explode(" ", $d));        
            $i++;
        }
        
        return $olah;
    }    
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Perhitungan Disposisi Surat</title>

    <!-- Bootstrap -->
    <link href="./bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="./bootstrap/css/bootstrap-narrow.css" rel="stylesheet">

</head>

<body>
    <div class="container">
        <div class="header clearfix">            
            <h3 class="text-muted">Perhitungan Disposisi Surat</h3>
        </div>
        
        <div class="row">
            <form method="post">
                <div class="form-group">                    
                    <div class="col-md-4">
                        <label for="indeks">Pilih Indeks Surat :</label>                        
                        <select name="indeks" id="in_indeks" class="form-control">
                            <option value="">None</option>
                            <option value="penting">penting</option>
                            <option value="biasa">biasa</option>
                        </select>                        
                    </div>
                    <div class="col-md-4">
                        <label for="jenis_surat">Pilih Jenis Surat :</label>
                        <select name="jenis_surat" id="in_jenis_surat" class="form-control">
                            <option value="">None</option>
                            <option value="undangan">undangan</option>
                            <option value="permohonan">permohonan</option>
							<option value="pemberitahuan">pemberitahuan</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label for="keterangan">Pilih keterangan Surat :</label>
                        <select name="keterangan" id="in_keterangan" class="form-control">
                            <option value="">None</option>
							<option value="sertifikat">sertifikat</option>
                            <option value="kegiatan">kegiatan</option>
                            <option value="pemateri">pemateri</option>
                        </select>
                    </div>                                                            
                    <div class="col-md-12" style="margin : 30px 0">
                        <button class="btn btn-primary btn-block" type="submit">Go!</button>                            
                    </div>                        
                </div>                
            </form>
        </div>
        
        <?php
        if (isset($_POST)) {
            $data_test = @[$_POST['indeks'], $_POST['jenis_surat'] ,$_POST['keterangan']];

            $nb = new NaiveBayes($data, ["indeks", "jenis_surat", "keterangan"]);
        
            $result = $nb->run()->predict($data_test);
            
            ?>
            
        <div class="row">            
            
            <div class="col-md-6">
                <label>surat perlu segera disposisi ?</label>
                <?= array_keys($result)[0] ?>
            </div>
        </div>

        <?php            
        }        
        ?>
        
        
                

        <footer class="footer">
            <p>&copy; Danyusuf | Distributed by <a href="#" target="_blank" rel="noopener noreferrer">ipnuippnubojonegoro.or.id</a></p>
        </footer>

    </div> <!-- /container -->

    <!-- jQuery Slim (necessary for Bootstrap's JavaScript plugins) -->
    <script src="./bootstrap/js/jquery.slim.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="./bootstrap/js/bootstrap.min.js"></script>
</body>

</html>
